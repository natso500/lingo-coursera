import {test} from 'node:test';
import assert from 'node:assert/strict';
import '../extension/core.js';
const C=globalThis.LingoCore;
test('parses VTT settings, markup, BOM, CRLF and skips metadata',()=>{
  const input='\uFEFFWEBVTT\r\n\r\nNOTE ignore\r\n00:00:00.000 --> 00:00:09.000\r\nignored\r\n\r\n1\r\n00:00:01.000 --> 00:00:03.500 align:start\r\n<v Speaker>Hello &amp; goodbye</v>\r\n';
  assert.deepEqual(C.parse(input),[{id:0,start:1,end:3.5,text:'Hello & goodbye'}]);
});
test('SRT roundtrip and invalid ranges',()=>{
  const cues=C.parse('1\n00:00:01,250 --> 00:00:02,750\nمرحبا\n\n2\n00:00:05,000 --> 00:00:03,000\nbad');
  assert.equal(cues.length,1); assert.deepEqual(C.parse(C.serialize(cues)),cues);
});
test('preserves overlapping cues and excludes exact end',()=>{
  const cues=[{start:0,end:2},{start:1,end:3}]; assert.equal(C.active(cues,1.5).length,2);assert.equal(C.active(cues,2).length,1);
});
test('reorders translation IDs and rejects duplicates or missing captions',()=>{
  const source=[{id:0,start:0,end:1,text:'a'},{id:1,start:1,end:2,text:'b'}];
  assert.equal(C.validateTranslation([{id:1,text:'ب'},{id:0,text:'أ'}],source)[0].text,'أ');
  assert.throws(()=>C.validateTranslation([{id:0,text:'أ'},{id:0,text:'ب'}],source));
  assert.throws(()=>C.validateTranslation([{id:4,text:'أ'},{id:1,text:'ب'}],source));
});
