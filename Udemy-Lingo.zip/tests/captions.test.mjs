import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import '../extension/core.js';

const script = await readFile(new URL('../extension/captions.js', import.meta.url), 'utf8');
const origin = 'https://www.udemy.com';
const cdn = 'https://vtt-c.udemycdn.com';
const english = cdn + '/22529686/en_US/caption.vtt';
const lecture = origin + '/api-2.0/users/me/subscribed-courses/88/lectures/18184872/';
const vtt = 'WEBVTT\n\n00:00:02.000 --> 00:00:04.250\nFirst line';

function fixture({resources = [], fetch = async () => { throw new Error('Unexpected fetch'); }} = {}) {
  const location = new URL('/course/example/learn/lecture/18184872', origin);
  const entries = resources.map(name => ({name}));
  let callback;
  class Observer {
    constructor(onEntries) { callback = onEntries; }
    observe(options) { assert.equal(options.type, 'resource'); }
    takeRecords() { return []; }
  }
  const context = vm.createContext({URL, location, AbortSignal, fetch, LingoCore,
    performance: {getEntriesByType: () => entries}, PerformanceObserver: Observer});
  vm.runInContext(script, context);
  const video = {id: 'lecture-22529686', isConnected: true, closest: () => null, textTracks: [], querySelectorAll: () => []};
  return {captions: context.UdemyCaptions, video, location, receive(url) {callback({getEntries: () => [{name: url}]});}};
}

test('reads the entire English VTT for the current Shaka asset, ignoring preloads and thumbnail sprites', async () => {
  const {captions, video} = fixture({resources: [
    english, cdn + '/999/en_US/other.vtt', cdn + '/22529686/es_ES/caption.vtt',
    'https://mp4-c.udemycdn.com/22529686/thumb-sprites.vtt'
  ]});
  const cues = await captions.read(video, async (type, {url}) => {
    assert.equal(type, 'captionFile');
    assert.equal(url, english);
    return {text: vtt};
  });
  assert.deepEqual(cues, [{id: 0, start: 2, end: 4.25, text: 'First line'}]);
});

test('selects recently observed resources after SPA navigation', async () => {
  const {captions, video, location, receive} = fixture({resources: [english]});
  video.id = 'lecture-888';
  location.pathname = '/course/example/learn/lecture/456';
  const next = cdn + '/888/en_GB/updated.vtt?Expires=1';
  receive(next);
  receive(cdn + '/777/en_US/prefetch.vtt');
  await captions.read(video, async (_type, {url}) => {
    assert.equal(url, next);
    return {text: vtt};
  });
});

test('after expiry requests only caption metadata from the current subscribed lecture', async () => {
  const refreshed = english + '?Expires=2';
  const {captions, video} = fixture({resources: [english, lecture, lecture.replace('/18184872/', '/999/')],
    fetch: async (input, options) => {
      const url = new URL(input);
      assert.equal(url.origin + url.pathname, lecture);
      assert.equal(url.searchParams.get('fields[asset]'), 'id,captions');
      assert.equal(options.credentials, 'same-origin');
      return {ok: true, json: async () => ({id: 18184872, asset: {id: 22529686, captions: [
        {url: cdn + '/777/en_US/incorrect.vtt'}, {url: refreshed}
      ]}})};
    }});
  const tried = [];
  await captions.read(video, async (_type, {url}) => {
    tried.push(url);
    if (url === english) throw new Error('Expired URL');
    return {text: vtt};
  });
  assert.deepEqual(tried, [english, refreshed]);
});

test('rejects an unrelated asset returned during navigation', async () => {
  const {captions, video} = fixture({resources: [lecture], fetch: async () => ({
    ok: true, json: async () => ({id: 18184872, asset: {id: 5, captions: [{url: english}]}})
  })});
  await assert.rejects(captions.read(video, () => assert.fail('Wrong asset requested')), /لم أجد/);
});

test('discards results if the lecture changes during the subtitle request', async () => {
  const {captions, video, location} = fixture({resources: [english]});
  await assert.rejects(captions.read(video, async () => {
    location.pathname = '/course/example/learn/lecture/500';
    return {text: vtt};
  }), /تغيرت المحاضرة/);
});

test('reads native English timestamps when no CDN resource exists', async () => {
  const {captions, video} = fixture();
  video.textTracks = [{kind: 'subtitles', language: 'en-US', cues: [
    {startTime: 3.5, endTime: 5, text: 'Second'}, {startTime: 1, endTime: 3, text: 'First'}
  ]}];
  const cues = await captions.read(video, () => assert.fail('Unexpected CDN request'));
  assert.deepEqual(Array.from(cues, cue => [cue.id, cue.start, cue.text]), [[0, 1, 'First'], [1, 3.5, 'Second']]);
});
