import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';

async function fixture() {
  const dom = new JSDOM('<div data-purpose="shaka-video-player"><video id="lecture-456"></video></div>', {
    url: 'https://www.udemy.com/course/example/learn/lecture/123', runScripts: 'outside-only'
  });
  const w = dom.window;
  let frame, root, finishBatch;
  const sent = [];
  const cache = new Map();
  const attach = w.Element.prototype.attachShadow;
  w.Element.prototype.attachShadow = function (options) { return root = attach.call(this, options); };
  w.requestAnimationFrame = fn => { frame = fn; };
  Object.defineProperty(w.crypto, 'subtle', {value: crypto.subtle});
  w.TextEncoder = TextEncoder;
  const video = w.document.querySelector('video');
  video.getBoundingClientRect = () => ({width: 700, height: 390, left: 0, top: 0, bottom: 390});
  const track = {kind:'captions', language:'en', cues: Array.from({length:8}, (_, i) =>
    ({startTime:i, endTime:i+1, text:'Line '+i}))};
  Object.defineProperty(video, 'textTracks', {value:[track]});
  w.chrome = {runtime: {sendMessage: async ({type, payload}) => {
    let data;
    switch (type) {
      case 'cacheGet': data = {data:cache.get(payload.key)}; break;
      case 'cacheSet': cache.set(payload.key,payload.data); break;
      case 'models': data = {models:[{id:'model',name:'Test model'}]}; break;
      case 'translate':
        sent.push(payload);
        await new Promise(resolve => { finishBatch = resolve; });
        data = {rows:payload.cues.map(({id}) => ({id, text:'الترجمة ' + id}))};
        break;
      default: throw new Error('Unexpected request ' + type);
    }
    return {ok:true,data};
  }}};
  for (const name of ['captions','core','panel','content']) {
    w.eval(await readFile(new URL('../extension/'+name+'.js', import.meta.url), 'utf8'));
  }
  const el = id => root.getElementById(id);
  await el('load').onclick();
  await el('models').onclick();
  return {dom, el, sent, cache, video, frame: time=>frame(time), finish:()=>finishBatch()};
}

test('stop completes one batch, resume requests the remaining cues and preserves timing', async () => {
  const f = await fixture();
  try {
    const first = f.el('start').onclick();
    assert.deepEqual(Array.from(f.sent[0].cues, c=>c.id), [0,1,2,3,4,5]);
    f.el('stop').onclick();
    f.finish();
    await first;
    assert.match(f.el('status').textContent, /تم الإيقاف/);
    assert.equal(f.el('progress').value, 6);
    const second = f.el('start').onclick();
    assert.deepEqual(Array.from(f.sent[1].cues,c=>c.id),[6,7]);
    f.finish();
    await second;
    f.video.currentTime = 7.5;
    f.frame(300);
    assert.equal(f.el('arabic').textContent,'الترجمة 7');
    assert.equal(f.el('original').textContent,'Line 7');
    f.video.currentTime = 8;
    f.frame(500);
    assert.equal(f.el('arabic').textContent,'');
  } finally { f.dom.window.close(); }
});

test('changing lecture while ChatGPT is working discards the previous lecture result', async () => {
  const f = await fixture();
  try {
    const work = f.el('start').onclick();
    f.dom.window.history.pushState({},'', '/course/example/learn/lecture/999');
    f.video.id = 'lecture-777';
    f.frame(250);
    f.finish();
    await work;
    assert.equal(f.el('progress').value,0);
    assert.equal(f.el('arabic').textContent,'');
    assert.equal(f.cache.size,0);
  } finally { f.dom.window.close(); }
});
