import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp, readFile, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';

test('paired companion validates sign-in, loads models and translates a batch through Responses', async () => {
  const dataDir = await mkdtemp(join(tmpdir(), 'udemy-lingo-test-'));
  const child = spawn(process.execPath, ['--import', './tests/chatgpt-fixture.mjs', 'server/index.mjs'], {
    stdio: ['ignore', 'pipe', 'pipe'],
    env: {...process.env, UDEMY_LINGO_PORT: '0', UDEMY_LINGO_DATA_DIR: dataDir}
  });
  const exited = once(child, 'exit');
  try {
    const {base, key} = await new Promise((resolve, reject) => {
      let output = '';
      const timer = setTimeout(() => reject(new Error('Companion did not start')), 10000);
      child.stdout.on('data', chunk => {
        output += chunk;
        const base = output.match(/http:\/\/127\.0\.0\.1:\d+/)?.[0];
        const key = output.match(/\b[a-f0-9]{64}\b/)?.[0];
        if (base && key) { clearTimeout(timer); resolve({base, key}); }
      });
      child.once('exit', () => { clearTimeout(timer); reject(new Error('Companion exited before ready')); });
    });
    const post = (route, body = {}) => fetch(base + route, {
      method: 'POST', headers: {'X-Lingo-Key': key, 'Content-Type': 'application/json'}, body: JSON.stringify(body)
    });
    assert.equal((await fetch(base + '/status', {method: 'POST'})).status, 403);
    assert.equal((await fetch(base + '/status', {method: 'POST', headers: {
      'X-Lingo-Key': key, Origin: 'https://www.udemy.com'
    }})).status, 403);
    assert.equal((await (await post('/status')).json()).connected, false);
    const auth = new URL((await (await post('/login')).json()).url);
    assert.equal(auth.origin, 'https://auth.openai.com');
    assert.equal(auth.searchParams.get('agent_name_hint'), 'Udemy Lingo');
    assert.equal(auth.searchParams.get('redirect_uri'), base + '/auth/callback');
    const bad = await fetch(base + '/auth/callback?state=wrong&code=fake');
    assert.match(await bad.text(), /تعذر التحقق/);

    const callback = new URL(auth.searchParams.get('redirect_uri'));
    callback.search = new URLSearchParams({state: auth.searchParams.get('state'),
      code: auth.searchParams.get('nonce'), client_id: 'oaiapp_fixture'});
    assert.match(await (await fetch(callback)).text(), /تم الربط بنجاح/);
    assert.equal((await (await post('/status')).json()).account, 'Fixture');
    assert.deepEqual((await (await post('/models')).json()).models, [{id: 'fixture-model', name: 'Test model'}]);
    const translated = await post('/translate', {model: 'fixture-model', cues: [{id: 0, text: 'Hello'}]});
    assert.deepEqual(await translated.json(), {rows: [{id: 0, text: 'مرحبًا'}]});
    const saved = JSON.parse(await readFile(join(dataDir, 'host.json'), 'utf8'));
    assert.deepEqual(Object.keys(saved).sort(), ['clientId', 'host', 'subject']);
    assert.equal((await post('/logout')).status, 200);
    assert.equal((await (await post('/status')).json()).connected, false);
  } finally {
    child.kill();
    await exited;
    await rm(dataDir, {recursive: true, force: true});
  }
});
