// Loaded only in the test companion's child process. The client, callback and
// loopback requests still use their normal production implementations.
import {generateKeyPairSync, sign} from 'node:crypto';

const {publicKey, privateKey} = generateKeyPairSync('rsa', {modulusLength: 2048});
const jwk = {...publicKey.export({format: 'jwk'}), kid: 'test-key', alg: 'RS256', use: 'sig'};
const encode = value => Buffer.from(JSON.stringify(value)).toString('base64url');

globalThis.fetch = async (url, options = {}) => {
  switch (String(url)) {
    case 'https://auth.openai.com/.well-known/jwks.json':
      return Response.json({keys: [jwk]});
    case 'https://auth.openai.com/api/accounts/oauth/token': {
      const form = options.body;
      if (form.get('grant_type') !== 'authorization_code' || !form.get('code_verifier')) {
        return Response.json({error: 'invalid_grant'}, {status: 400});
      }
      const now = Math.floor(Date.now() / 1000);
      const claims = {iss: 'https://auth.openai.com', sub: 'test-account', aud: form.get('client_id'),
        iat: now, exp: now + 3600, nonce: form.get('code'), name: 'Fixture'};
      const signed = encode({alg: 'RS256', kid: jwk.kid}) + '.' + encode(claims);
      const signature = sign('RSA-SHA256', Buffer.from(signed), privateKey).toString('base64url');
      return Response.json({id_token: signed + '.' + signature, access_token: 'test-access',
        scope: 'openid chatgpt.tokens.use.direct', expires_in: 3600});
    }
    case 'https://api.openai.com/v1/models':
      if (options.headers.Authorization !== 'Bearer test-access') return new Response(null, {status: 401});
      return Response.json({models: [
        {slug: 'fixture-model', display_name: 'Test model', visibility: 'list'},
        {slug: 'unlisted', visibility: 'hide'}
      ]});
    case 'https://api.openai.com/v1/responses': {
      const request = JSON.parse(options.body);
      if (options.headers.Authorization !== 'Bearer test-access' || request.model !== 'fixture-model' ||
          request.stream !== true || request.store !== false) return new Response(null, {status: 400});
      const rows = JSON.parse(request.input[0].content).map(cue => ({id: cue.id, text: 'مرحبًا'}));
      const delta = {type: 'response.output_text.delta', delta: JSON.stringify(rows)};
      return new Response('data: ' + JSON.stringify(delta) + '\n\ndata: {"type":"response.completed"}\n\n',
        {headers: {'Content-Type': 'text/event-stream'}});
    }
    default:
      throw new Error('Unexpected upstream request in ChatGPT fixture');
  }
};
