/* Udemy's Shaka player fetches subtitle files without creating HTML track elements. */
(() => {
  const captionOrigin = 'https://vtt-c.udemycdn.com';
  const englishFile = /^\/(\d+)\/en(?:[-_][a-z0-9]+)*\/[^/]+\.vtt$/i;
  const lectureAPI = /^\/api-2\.0\/users\/me\/subscribed-courses\/\d+\/lectures\/(\d+)\/$/;
  const files = new Map();
  const lectures = new Map();

  function remember(map, id, value) {
    map.delete(id);
    map.set(id, value);
    if (map.size > 64) map.delete(map.keys().next().value);
  }

  function assetId(video) {
    return video?.id?.match(/^lecture-(\d+)$/)?.[1]
      || video?.closest('[id^="shaka-video-container-"]')?.id.match(/^shaka-video-container-(\d+)$/)?.[1]
      || '';
  }

  function englishFileId(url) {
    if (url.origin !== captionOrigin || url.username || url.password) return '';
    return url.pathname.match(englishFile)?.[1] || '';
  }

  function record(entries) {
    for (const {name} of entries) {
      if (!name.startsWith(captionOrigin + '/') && !name.startsWith(location.origin + '/api-2.0/')) continue;
      const url = new URL(name);
      const asset = englishFileId(url);
      if (asset) remember(files, asset, url.href);
      if (url.origin === location.origin) {
        const lecture = url.pathname.match(lectureAPI)?.[1];
        if (lecture) remember(lectures, lecture, url.pathname);
      }
    }
  }

  // Keep just the caption URL and lecture metadata path as the student changes lessons.
  record(performance.getEntriesByType?.('resource') || []);
  let observer;
  if (typeof PerformanceObserver !== 'undefined') {
    observer = new PerformanceObserver(list => record(list.getEntries()));
    observer.observe({type: 'resource', buffered: true});
  }

  function isEnglish(track) {
    const language = track.language || track.srclang;
    return language ? /^en(?:[-_]|$)/i.test(language) : /^English(?:\b|$)/i.test(track.label || '');
  }

  function nativeCues(video) {
    for (const track of Array.from(video.textTracks || [])) {
      if (!['captions', 'subtitles'].includes(track.kind) || !isEnglish(track) || !track.cues?.length) continue;
      const cues = Array.from(track.cues, cue => ({
        start: cue.startTime, end: cue.endTime, text: cue.getCueAsHTML?.().textContent?.trim() || cue.text?.trim()
      })).filter(cue => Number.isFinite(cue.start) && Number.isFinite(cue.end) && cue.end > cue.start && cue.text);
      if (cues.length) return cues.sort((a, b) => a.start - b.start).map((cue, id) => ({...cue, id}));
    }
    return null;
  }

  function supported(raw, expectedAsset, native = false) {
    if (typeof raw !== 'string' || !raw) return false;
    let url;
    try { url = new URL(raw, location.href); } catch { return false; }
    if (url.username || url.password) return false;
    if (native && url.origin === location.origin && /\.vtt$/i.test(url.pathname)) return true;
    const asset = englishFileId(url);
    return Boolean(asset && (!expectedAsset || asset === expectedAsset));
  }

  async function readFile(raw, message) {
    const url = new URL(raw, location.href);
    let text;
    if (url.origin === location.origin) {
      const response = await fetch(url.href, {
        credentials: 'same-origin', redirect: 'error', signal: AbortSignal.timeout(15000)
      });
      if (!response.ok) throw new Error('تعذر تحميل ملف الترجمة الإنجليزية.');
      text = await response.text();
    } else {
      ({text} = await message('captionFile', {url: url.href}));
    }
    if (typeof text !== 'string' || text.length > 2000000) throw new Error('تعذرت قراءة ملف الترجمة الإنجليزية.');
    const cues = LingoCore.parse(text);
    if (!cues.length) throw new Error('ملف الترجمة لا يحتوي على مقاطع موقّتة.');
    return cues;
  }

  async function lookup(lecture, expectedAsset) {
    const path = lectures.get(lecture);
    if (!path) return '';
    // Ask the same subscribed-lecture endpoint already used by this tab for captions only.
    const url = new URL(path, location.origin);
    url.searchParams.set('fields[lecture]', 'id,asset');
    url.searchParams.set('fields[asset]', 'id,captions');
    const response = await fetch(url.href, {
      credentials: 'same-origin', redirect: 'error', signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) throw new Error('تعذرت قراءة بيانات نص المحاضرة. حدّث تبويب Udemy ثم أعد المحاولة.');
    const data = await response.json();
    if (data.id != null && String(data.id) !== lecture) return '';
    const asset = data.asset;
    if (!asset || (expectedAsset && asset.id != null && String(asset.id) !== expectedAsset)) return '';
    return (Array.isArray(asset.captions) ? asset.captions : [])
      .find(caption => supported(caption?.url, expectedAsset || String(asset.id || '')))?.url || '';
  }

  async function read(video, message) {
    const path = location.pathname;
    const lecture = path.match(/\/learn\/lecture\/(\d+)(?:\/|$)/)?.[1];
    const asset = assetId(video);
    function current() {
      if (location.pathname !== path || !video.isConnected || assetId(video) !== asset) {
        throw new Error('تغيرت المحاضرة. اضغط قراءة النص الأصلي مجددًا.');
      }
    }
    current();

    const native = nativeCues(video);
    if (native) return native;
    record(observer ? observer.takeRecords() : (performance.getEntriesByType?.('resource') || []));
    const track = Array.from(video.querySelectorAll('track[src]')).find(item =>
      ['', 'subtitles', 'captions'].includes(item.getAttribute('kind') || '') &&
      isEnglish(item) && supported(item.src, asset, true));
    const candidate = track?.src || files.get(asset);
    if (candidate) {
      try {
        const cues = await readFile(candidate, message);
        current();
        return cues;
      } catch (error) {
        current();
        if (!lectures.has(lecture)) throw error;
        // A previously fetched URL may have expired. Re-read the lesson's caption metadata.
      }
    }

    const fresh = await lookup(lecture, asset);
    current();
    if (!fresh) throw new Error('لم أجد نصًا إنجليزيًا موقّتًا لهذه المحاضرة. اختر الإنجليزية من زر CC، ثم أعد قراءة النص.');
    const cues = await readFile(fresh, message);
    current();
    return cues;
  }

  globalThis.UdemyCaptions = {assetId, read};
})();
