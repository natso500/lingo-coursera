(() => {
  const stylesheet = `:host{all:initial;position:fixed;inset:0;z-index:2147483000;pointer-events:none;font-family:Segoe UI,Tahoma,sans-serif;color:#ecf4fa}
    *{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;border:0;border-radius:9px;padding:9px 12px;background:#82e4cd;color:#092b23;font-weight:600}button:disabled{opacity:.45;cursor:default}button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #ffd289;outline-offset:2px}
    #toggle{position:absolute;bottom:22px;left:22px;pointer-events:auto;box-shadow:0 5px 24px #0005;padding:12px 18px}
    #panel{pointer-events:auto;position:absolute;left:22px;bottom:76px;width:350px;max-width:calc(100vw - 24px);max-height:75vh;overflow:auto;background:#13212df5;border:1px solid #3c5364;border-radius:18px;padding:21px;box-shadow:0 12px 50px #0006;direction:rtl;font-size:14px;line-height:1.7}
    [hidden]{display:none!important}.brand{letter-spacing:2px;color:#82e4cd;font-size:10px}h2{margin:4px 0 8px;font-size:24px}p{margin:9px 0;color:#b5c8d7}.muted{font-size:12px}label{display:block;margin:10px 0 4px}.row{display:flex;gap:7px;flex-wrap:wrap}.row>*{flex:1}.secondary{background:#2b4152;color:#edf4f9}select{background:#203545;color:#edf4f9;width:100%;padding:9px;border:1px solid #486073;border-radius:8px}input[type=range]{width:100%;accent-color:#82e4cd}progress{width:100%;height:8px;accent-color:#82e4cd}#status{color:#ffda9e;white-space:pre-wrap}#captions{position:fixed;text-align:center;pointer-events:none;direction:rtl;padding:0 15px;line-height:1.55}#arabic,#original{white-space:pre-line;display:table;margin:4px auto;background:#071019e8;color:#fff;padding:3px 12px;border-radius:7px;text-shadow:0 1px 2px #000;max-width:100%}#original{font-size:16px;direction:ltr;color:#d8e6ef}#arabic:empty,#original:empty{display:none}.line{border-top:1px solid #304655;margin:15px 0}a{color:#82e4cd}
    :host([hidden]) { display:none !important; }
    #panel { z-index:1; }
    #toggle { z-index:2; }
    #captions { overflow-wrap:anywhere; }
  `;

  function element(tag, attributes, ...children) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(attributes)) node.setAttribute(name, value);
    node.append(...children);
    return node;
  }

  function button(id, text, secondary = true) {
    return element('button', {id, type:'button', class:secondary ? 'secondary' : ''}, text);
  }

  function row(...children) {
    return element('div', {class:'row'}, ...children);
  }

  function check(id, text) {
    return element('label', {}, element('input', {id, type:'checkbox', checked:''}), ' ' + text);
  }

  function range(id, label, min, max, value) {
    return [
      element('label', {for:id}, label),
      element('input', {id, type:'range', min, max, value})
    ];
  }

  function create() {
    const host = element('div', {id:'udemy-lingo', lang:'ar', translate:'no'});
    const root = host.attachShadow({mode:'closed'});
    if (typeof CSSStyleSheet === 'function' && 'replaceSync' in CSSStyleSheet.prototype) {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(stylesheet);
      root.adoptedStyleSheets = [sheet];
    } else {
      root.append(element('style', {}, stylesheet));
    }

    const toggle = button('toggle', 'Lingo · ترجمة', false);
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-controls', 'panel');
    const stop = button('stop', 'إيقاف بعد الدفعة');
    stop.disabled = true;
    const panel = element('section', {id:'panel', hidden:'', 'aria-label':'ترجمة فيديو يوديمي'},
      element('span', {class:'brand'}, 'UDEMY LINGO'),
      element('h2', {}, 'افهم كل كلمة.'),
      element('p', {class:'muted'}, 'ترجمة عربية متزامنة، باستخدام حساب ChatGPT.'),
      row(button('load', 'قراءة النص الأصلي'), button('settings', 'إعداد الاتصال')),
      element('label', {for:'model'}, 'نموذج حسابك'),
      element('select', {id:'model'}, element('option', {value:''}, 'اضغط تحميل النماذج')),
      button('models', 'تحميل النماذج'),
      element('p', {class:'muted'}, 'بدء الترجمة يرسل نص المحاضرة إلى OpenAI ويستخدم حدود اشتراكك. يُحفظ الناتج في هذا المتصفح.'),
      row(button('start', 'ترجمة المحاضرة', false), stop),
      element('progress', {id:'progress', value:'0', max:'1'}),
      element('p', {id:'status', role:'status', 'aria-live':'polite'}, 'افتح محاضرة ثم اضغط قراءة النص الأصلي.'),
      element('div', {class:'line'}),
      check('show', 'عرض الترجمة العربية'),
      check('dual', 'عرض النص الإنجليزي أيضًا'),
      ...range('size', 'حجم الخط', 18, 40, 25),
      ...range('offset', 'موضع الترجمة فوق أدوات الفيديو', 45, 180, 76),
      element('div', {class:'line'}),
      row(button('prompt', 'تصدير طلب لـ ChatGPT'), button('import', 'استيراد ترجمة')),
      row(button('export', 'تصدير VTT'), button('clear', 'مسح ترجمة المحاضرة')),
      element('input', {id:'file', type:'file', accept:'.json,.vtt,.srt', hidden:''}),
      element('p', {class:'muted'}, 'يدعم JSON المطابق للمقاطع أو VTT/SRT الموقّت. لا يترجم الصوت إذا لم يتوفر نص.')
    );
    root.append(toggle, panel, element('div', {id:'captions', hidden:''},
      element('div', {id:'arabic', lang:'ar'}), element('div', {id:'original', lang:'en'})));
    root.addEventListener('keydown', event => event.stopPropagation());
    root.addEventListener('click', event => event.stopPropagation());
    document.documentElement.append(host);
    return {host, byId:id => root.getElementById(id)};
  }

  globalThis.UdemyLingoPanel = {create};
})();
