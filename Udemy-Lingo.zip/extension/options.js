const $ = id => document.getElementById(id);
async function request(type) {
  const reply = await chrome.runtime.sendMessage({type});
  if (!reply?.ok) throw new Error(reply?.error || 'تعذر الاتصال.');
  return reply.data;
}
async function status() {
  const data = await request('status');
  $('account').textContent = data.connected ? `متصل: ${data.account} — جاهز لاختيار نموذج من صفحة الفيديو.` : 'المساعد يعمل. أكمل تسجيل الدخول بحساب ChatGPT.';
  $('status').textContent = data.authError || '';
}
for (const id of ['save', 'refresh', 'login', 'logout']) $(id).onclick = async () => {
  $(id).disabled = true;
  try {
    if (id === 'save') {
      const connectorKey = $('key').value.trim();
      if (!/^[a-f0-9]{64}$/.test(connectorKey)) throw new Error('انسخ رمز الربط الكامل من نافذة المساعد المحلي.');
      await chrome.storage.local.set({connectorKey}); $('key').value = '';
    }
    if (id === 'login') {
      const data = await request('login');
      await chrome.tabs.create({url: data.url});
      $('status').textContent = 'أكمل تسجيل الدخول في التبويب الجديد ثم اضغط تحديث حالة الاتصال.';
    } else if (id === 'logout') {
      const data = await request('logout'); await status(); $('status').textContent = data.warning || 'تم تسجيل الخروج.';
    } else await status();
  } catch (e) { $('status').textContent = e.message; }
  finally { $(id).disabled = false; }
};
status().catch(e => { $('status').textContent = e.message; });
