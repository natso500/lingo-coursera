import {readdir,readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
for (const dir of ['extension','server']) {
  for (const file of await readdir(dir)) {
    if (!/\.(js|mjs)$/.test(file)) continue;
    const result=spawnSync(process.execPath,['--check',`${dir}/${file}`],{encoding:'utf8'});
    if(result.status!==0) throw new Error(result.stderr);
  }
}
const manifest=JSON.parse(await readFile('extension/manifest.json','utf8'));
if(manifest.manifest_version!==3 || manifest.host_permissions.some(p=>p.includes('<all_urls>'))) throw new Error('Unexpected manifest');
console.log('JavaScript syntax and manifest checks passed.');
