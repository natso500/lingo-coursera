import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';

test('local companion rejects unpaired and web-origin requests, accepts paired status',async()=>{
  const child=spawn(process.execPath,['server/index.mjs'],{stdio:['ignore','pipe','pipe']});
  try {
    const key=await new Promise((resolve,reject)=>{
      let output='';const timer=setTimeout(()=>reject(new Error('Companion did not start')),10000);
      child.stdout.on('data',chunk=>{output+=chunk;const match=output.match(/\b[a-f0-9]{64}\b/);if(match){clearTimeout(timer);resolve(match[0]);}});
      child.on('exit',()=>{clearTimeout(timer);reject(new Error('Companion exited before ready'));});
    });
    const base='http://127.0.0.1:43127';
    assert.equal((await fetch(base+'/status',{method:'POST'})).status,403);
    assert.equal((await fetch(base+'/status',{method:'POST',headers:{'X-Lingo-Key':key,Origin:'https://www.coursera.org'}})).status,403);
    const result=await fetch(base+'/status',{method:'POST',headers:{'X-Lingo-Key':key,'Content-Type':'application/json'},body:'{}'});
    assert.equal(result.status,200);assert.equal((await result.json()).connected,false);
    const badCallback=await fetch(base+'/auth/callback?state=wrong&code=fake');assert.match(await badCallback.text(),/تعذر التحقق/);
  } finally {child.kill();await once(child,'exit');}
});
