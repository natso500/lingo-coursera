import {test} from 'node:test';
import assert from 'node:assert/strict';
import {transaction,validateCallback,validateBatch,readEvents} from '../server/protocol.mjs';
test('OAuth uses stable host, PKCE, dynamic registration and issued ID',()=>{
  const {tx,url}=transaction('urn:uuid:test',null,'http://127.0.0.1:43127/auth/callback');const u=new URL(url);
  assert.equal(u.searchParams.get('client_id'),'dynamic_agent_client'); assert.equal(u.searchParams.get('code_challenge_method'),'S256');
  const cb=new URL(tx.redirect);cb.search=new URLSearchParams({state:tx.state,code:'code',client_id:'oaiapp_test'});
  assert.equal(validateCallback(cb,tx).clientId,'oaiapp_test');
  cb.searchParams.set('state','wrong');assert.throws(()=>validateCallback(cb,tx));
});
test('reauthorization rejects different client, expired state and denied consent',()=>{
  const {tx}=transaction('host','oaiapp_saved','http://127.0.0.1:43127/auth/callback');const cb=new URL(tx.redirect);
  cb.search=new URLSearchParams({state:tx.state,code:'c',client_id:'other'});assert.throws(()=>validateCallback(cb,tx));
  cb.searchParams.delete('client_id');assert.equal(validateCallback(cb,tx).clientId,'oaiapp_saved');
  cb.searchParams.set('error','access_denied');assert.throws(()=>validateCallback(cb,tx));cb.searchParams.delete('error');
  assert.throws(()=>validateCallback(cb,{...tx,expires:1}));
});
test('validates bounded translation input',()=>{
  assert.throws(()=>validateBatch({model:'x',cues:[{id:0,text:'a'},{id:0,text:'b'}]}));
  assert.throws(()=>validateBatch({model:'x',cues:Array(13).fill({id:0,text:'a'})}));
  assert.equal(validateBatch({model:'x',cues:[{id:0,text:'valid'}]}).cues.length,1);
});
const stream=async function*(text){const data=Buffer.from(text);for(let i=0;i<data.length;i+=7)yield data.subarray(i,i+7);};
test('SSE handles fragmented UTF-8 and requires terminal completion',async()=>{
  const text='data: '+JSON.stringify({type:'response.output_text.delta',delta:'مرحبا'})+'\r\n\r\ndata: {"type":"response.completed"}\n\n';
  assert.equal(await readEvents(stream(text)),'مرحبا');
  await assert.rejects(readEvents(stream('data: {"type":"response.output_text.delta","delta":"partial"}\n')));
  await assert.rejects(readEvents(stream('data: {"type":"response.failed","response":{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}}\n')));
});
