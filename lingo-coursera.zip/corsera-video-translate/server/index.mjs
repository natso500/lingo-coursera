import http from 'node:http';
import {randomUUID, timingSafeEqual} from 'node:crypto';
import {readFile, mkdir, writeFile, rename} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {createRemoteJWKSet, jwtVerify} from 'jose';
import {transaction, validateCallback, validateBatch, translationRequest, translationError, readEvents, random} from './protocol.mjs';
import '../extension/core.js';

const PORT = 43127, HOST = `127.0.0.1:${PORT}`, RESOURCE = 'https://api.openai.com/v1';
const dataDir = fileURLToPath(new URL('../.local/', import.meta.url));
await mkdir(dataDir, {recursive: true});
let metadata;
try { metadata = JSON.parse(await readFile(dataDir + '/host.json', 'utf8')); }
catch (e) { if (e.code !== 'ENOENT') throw e; metadata = {host: `urn:uuid:${randomUUID()}`}; }
const persist = async () => { await writeFile(dataDir + '/host.tmp', JSON.stringify(metadata), {mode: 0o600}); await rename(dataDir + '/host.tmp', dataDir + '/host.json'); };
await persist();
// OAuth credentials deliberately live only in this process, never in browser storage or on disk.
const connectorKey = random();
let pending, account = null, authError = '', refreshPromise, busy = false, generation = 0;
const jwks = createRemoteJWKSet(new URL('https://auth.openai.com/.well-known/jwks.json'));
const send = (res, status, data) => { res.writeHead(status, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'}); res.end(JSON.stringify(data)); };
const tokenRequest = async fields => {
  const response = await fetch('https://auth.openai.com/api/accounts/oauth/token', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:new URLSearchParams({...fields, resource:RESOURCE}), signal:AbortSignal.timeout(15000)});
  if (!response.ok) throw new Error(`تعذر تجديد أو إكمال تسجيل الدخول (${response.status}). سجّل الدخول مجددًا.`);
  return response.json();
};
async function access() {
  if (!account) throw new Error('سجّل الدخول بحساب ChatGPT من إعدادات الإضافة.');
  if (account.expires > Date.now() + 60000) return account.access_token;
  if (!refreshPromise) {
    const current = account, epoch = generation;
    refreshPromise = (async () => {
      if (!current.refresh_token) throw new Error('انتهت الجلسة. سجّل الدخول مجددًا.');
      const tokens = await tokenRequest({grant_type:'refresh_token', client_id:current.clientId, refresh_token:current.refresh_token});
      if (epoch !== generation || account !== current) throw new Error('تغيرت جلسة الحساب.');
      if (!tokens.access_token || (tokens.scope && !tokens.scope.split(' ').includes('chatgpt.tokens.use.direct'))) throw new Error('لم يعد استخدام اشتراك ChatGPT مصرحًا.');
      account = {...current, ...tokens, expires:Date.now() + Number(tokens.expires_in || 3600)*1000};
      return account.access_token;
    })().finally(() => { refreshPromise = null; });
  }
  return refreshPromise;
}
async function models() {
  const response = await fetch(RESOURCE + '/models', {headers:{Authorization:`Bearer ${await access()}`}, signal:AbortSignal.timeout(15000)});
  if (!response.ok) throw new Error(`تعذر تحميل نماذج حسابك (${response.status}).`);
  const data = await response.json();
  return (data.models || []).filter(m => m.visibility === 'list').map(m => ({id:m.slug, name:m.display_name || m.slug}));
}
async function translate(body) {
  validateBatch(body);
  if (busy) throw new Error('هناك دفعة ترجمة قيد التنفيذ. انتظر ثم أعد المحاولة.');
  busy = true; const epoch = generation;
  try {
    const response = await fetch(RESOURCE + '/responses', {
      method:'POST', headers:{Authorization:`Bearer ${await access()}`, 'Content-Type':'application/json'}, signal:AbortSignal.timeout(21000),
      body:JSON.stringify(translationRequest(body))
    });
    if (!response.ok) throw await translationError(response);
    const text = await readEvents(response.body);
    if (epoch !== generation) throw new Error('تغيرت الجلسة أثناء الترجمة.');
    let rows;
    try { rows = JSON.parse(text.trim().replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch { throw new Error('لم يُرجع النموذج ترجمة منظمة. جرّب نموذجًا آخر.'); }
    return LingoCore.validateTranslation(rows, body.cues).map(({id,text}) => ({id,text}));
  } finally { busy = false; }
}
async function readBody(req) {
  let size = 0, chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > 100000) throw new Error('الطلب كبير جدًا.'); chunks.push(chunk); }
  return JSON.parse(Buffer.concat(chunks).toString() || '{}');
}
function allowed(req) {
  const key = req.headers['x-lingo-key'];
  const origin = req.headers.origin;
  return (!origin || /^chrome-extension:\/\/[a-p]{32}$/.test(origin)) && typeof key === 'string' && key.length === connectorKey.length && timingSafeEqual(Buffer.from(key), Buffer.from(connectorKey));
}
const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  if (req.headers.host !== HOST) return send(res, 403, {error:'Host rejected'});
  const url = new URL(req.url, `http://${HOST}`);
  if (url.pathname === '/auth/callback' && req.method === 'GET') {
    let message;
    try {
      const tx = pending;
      // An unrelated request must not consume a valid pending transaction.
      if (tx && url.searchParams.get('state') === tx.state) pending = null;
      const {clientId, code} = validateCallback(url, tx);
      const epoch = generation;
      const tokens = await tokenRequest({grant_type:'authorization_code', client_id:clientId, code, code_verifier:tx.verifier, redirect_uri:tx.redirect});
      const {payload} = await jwtVerify(tokens.id_token, jwks, {issuer:'https://auth.openai.com', audience:clientId, requiredClaims:['sub','exp','iat'], clockTolerance:5});
      if (payload.nonce !== tx.nonce || (metadata.subject && metadata.subject !== payload.sub)) throw new Error('هوية الحساب لا تطابق محاولة تسجيل الدخول.');
      if (!tokens.access_token || !String(tokens.scope || '').split(' ').includes('chatgpt.tokens.use.direct')) throw new Error('لم يُسمح باستخدام الاشتراك. راجع إعدادات التطبيق في حساب ChatGPT.');
      if (generation !== epoch) throw new Error('تم إلغاء تسجيل الدخول.');
      account = {...tokens, clientId, label:payload.email || payload.name || 'ChatGPT', expires:Date.now() + Number(tokens.expires_in || 3600)*1000};
      metadata.clientId = clientId; metadata.subject = payload.sub; await persist(); authError = ''; generation++;
      message = 'تم الربط بنجاح. ارجع إلى إعدادات الإضافة واضغط تحديث حالة الاتصال، ثم افتح فيديو كورسيرا.';
    } catch (e) { authError = e.message.startsWith('JWT') ? 'تعذر التحقق من هوية الحساب.' : e.message; message = authError; }
    res.writeHead(200, {'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'}); res.end(message); return;
  }
  if (req.method === 'OPTIONS') {
    const origin = req.headers.origin;
    if (!/^chrome-extension:\/\/[a-p]{32}$/.test(origin || '')) return send(res,403,{error:'Origin rejected'});
    res.writeHead(204, {'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST','Access-Control-Allow-Headers':'content-type,x-lingo-key','Access-Control-Allow-Private-Network':'true','Vary':'Origin'}); res.end(); return;
  }
  if (req.method !== 'POST' || !allowed(req)) return send(res,403,{error:'رمز الربط غير صحيح. انسخ الرمز من نافذة المساعد الحالي.'});
  if (req.headers.origin) res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
  try {
    const body = await readBody(req);
    if (url.pathname === '/status') return send(res,200,{connected:!!account, account:account?.label, authError});
    if (url.pathname === '/login') {
      const result = transaction(metadata.host, metadata.clientId, `http://${HOST}/auth/callback`);
      pending = result.tx; authError = ''; return send(res,200,{url:result.url});
    }
    if (url.pathname === '/logout') {
      const old = account; account = null; pending = null; generation++; authError = '';
      let warning = '';
      if (old?.refresh_token) {
        try {
          const config = await fetch('https://auth.openai.com/.well-known/openid-configuration', {signal:AbortSignal.timeout(5000)}).then(r=>r.json());
          const endpoint = new URL(config.revocation_endpoint);
          if (endpoint.origin !== 'https://auth.openai.com') throw new Error('Unexpected endpoint');
          const result = await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({token:old.refresh_token,token_type_hint:'refresh_token',client_id:old.clientId}),signal:AbortSignal.timeout(5000)});
          if (!result.ok) throw new Error('Revocation failed');
        } catch { warning = 'تم مسح الجلسة محليًا؛ لم نتأكد من إلغائها لدى OpenAI. يمكنك فصل التطبيق من إعدادات ChatGPT.'; }
      }
      return send(res,200,{warning});
    }
    if (url.pathname === '/models') return send(res,200,{models:await models()});
    if (url.pathname === '/translate') return send(res,200,{rows:await translate(body)});
    return send(res,404,{error:'Not found'});
  } catch(e) { send(res,400,{error:e.name === 'TimeoutError' ? 'استغرق الطلب وقتًا طويلًا. أعد المحاولة؛ قد يكون استُهلك جزء من حد الاشتراك.' : e.message}); }
});
server.requestTimeout = 30000;
server.on('error', e => { console.error(e.code === 'EADDRINUSE' ? 'المساعد يعمل بالفعل على المنفذ 43127. استخدم نافذته الحالية.' : 'تعذر تشغيل المساعد المحلي.'); process.exitCode = 1; });
server.listen(PORT, '127.0.0.1', () => {
  console.log('\nCoursera Lingo — local companion\nKeep this window open. Paste this local pairing code into the extension settings:\n');
  console.log(connectorKey);
  console.log('\nOAuth tokens stay in memory. Close this window to end the local session.\n');
});
