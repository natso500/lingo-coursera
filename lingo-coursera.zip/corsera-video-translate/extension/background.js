const BASE = 'http://127.0.0.1:43127';
// Prevent content scripts from reading the local connector credential.
chrome.storage.local.setAccessLevel({accessLevel: 'TRUSTED_CONTEXTS'});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  const isOptions = sender.url === chrome.runtime.getURL('options.html');
  const isCourse = /^https:\/\/www\.coursera\.org\//.test(sender.url || '');
  if (sender.id !== chrome.runtime.id || (!isOptions && !isCourse)) return false;
  if (isCourse && ['cacheGet','cacheSet'].includes(message.type)) {
    (async () => {
      const {key,data} = message.payload || {};
      if (!/^v1-ar-[a-f0-9]{64}$/.test(key || '')) throw new Error('Invalid cache key');
      const storageKey = 'captions:' + key;
      if (message.type === 'cacheGet') {
        const saved = await chrome.storage.local.get(storageKey); reply({ok:true,data:{data:saved[storageKey]?.data}}); return;
      }
      if (new TextEncoder().encode(JSON.stringify(data)).length > 750000) throw new Error('الترجمة كبيرة جدًا للحفظ المحلي. يمكنك تصديرها قبل إغلاق الصفحة.');
      await chrome.storage.local.set({[storageKey]:{data,updated:Date.now()}});
      const all = await chrome.storage.local.get(null);
      const old = Object.entries(all).filter(([k])=>k.startsWith('captions:')).sort((a,b)=>b[1].updated-a[1].updated).slice(8).map(([k])=>k);
      if (old.length) await chrome.storage.local.remove(old);
      reply({ok:true,data:{}});
    })().catch(e=>reply({ok:false,error:e.message}));
    return true;
  }
  const routes = {status: '/status', models: '/models', translate: '/translate'};
  if (isOptions) Object.assign(routes, {login: '/login', logout: '/logout'});
  if (message.type === 'options' && isCourse) {
    chrome.runtime.openOptionsPage(); reply({ok: true}); return false;
  }
  if (!routes[message.type]) return false;
  (async () => {
    const {connectorKey} = await chrome.storage.local.get('connectorKey');
    if (!connectorKey) throw new Error('افتح إعدادات الإضافة وأدخل رمز ربط المساعد المحلي.');
    const response = await fetch(BASE + routes[message.type], {
      method: 'POST', headers: {'Content-Type': 'application/json', 'X-Lingo-Key': connectorKey},
      body: JSON.stringify(message.payload || {}), signal: AbortSignal.timeout(24000)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `تعذر الاتصال (${response.status}).`);
    reply({ok: true, data});
  })().catch(error => reply({ok: false, error: error.name === 'TypeError' ? 'شغّل المساعد المحلي بواسطة START.cmd ثم أعد المحاولة.' : error.message}));
  return true;
});
