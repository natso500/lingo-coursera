import {test} from 'node:test';
import assert from 'node:assert/strict';
import {transaction,validateCallback,validateBatch,translationRequest,translationError,readEvents} from '../server/protocol.mjs';
test('OAuth uses stable host, PKCE, dynamic registration and issued ID',()=>{
  const {tx,url}=transaction('urn:uuid:test',null,'http://127.0.0.1:43129/auth/callback');const u=new URL(url);
  assert.equal(u.searchParams.get('client_id'),'dynamic_agent_client'); assert.equal(u.searchParams.get('code_challenge_method'),'S256');
  const cb=new URL(tx.redirect);cb.search=new URLSearchParams({state:tx.state,code:'code',client_id:'oaiapp_test'});
  assert.equal(validateCallback(cb,tx).clientId,'oaiapp_test');
  cb.searchParams.set('state','wrong');assert.throws(()=>validateCallback(cb,tx));
});
test('reauthorization rejects different client, expired state and denied consent',()=>{
  const {tx}=transaction('host','oaiapp_saved','http://127.0.0.1:43129/auth/callback');const cb=new URL(tx.redirect);
  cb.search=new URLSearchParams({state:tx.state,code:'c',client_id:'other'});assert.throws(()=>validateCallback(cb,tx));
  cb.searchParams.delete('client_id');assert.equal(validateCallback(cb,tx).clientId,'oaiapp_saved');
  cb.searchParams.set('error','access_denied');assert.throws(()=>validateCallback(cb,tx));cb.searchParams.delete('error');
  assert.throws(()=>validateCallback(cb,{...tx,expires:1}));
});
test('validates bounded translation input',()=>{
  assert.throws(()=>validateBatch({model:'x',cues:[{id:0,text:'a'},{id:0,text:'b'}]}));
  assert.throws(()=>validateBatch({model:'x',cues:Array(13).fill({id:0,text:'a'})}));
  assert.equal(validateBatch({model:'x',cues:[{id:0,text:'valid'}]}).cues.length,1);
});
test('uses a user-message array for ChatGPT plan translation', () => {
  const payload = translationRequest({model:'gpt-6.2-sol', cues:[{id:1, text:'Hello', start:30}]});
  assert.equal(payload.store, false);
  assert.equal(payload.stream, true);
  assert.deepEqual(payload.input, [{role:'user', content:'[{"id":1,"text":"Hello"}]'}]);
});
test('shows the upstream rejection from either error shape', async () => {
  const structured = Response.json({error:{message:'Input must be an array', param:'input', code:'invalid_type'}}, {status:400, headers:{'x-request-id':'req_test'}});
  assert.match((await translationError(structured)).message, /400.*\nInput must be an array\ninvalid_type · input · req_test/);
  const direct = Response.json({detail:'Direct routing unavailable'}, {status:503});
  assert.match((await translationError(direct)).message, /503.*\nDirect routing unavailable/);
});
const stream=async function*(text){const data=Buffer.from(text);for(let i=0;i<data.length;i+=7)yield data.subarray(i,i+7);};
test('SSE handles fragmented UTF-8 and requires terminal completion',async()=>{
  const text='data: '+JSON.stringify({type:'response.output_text.delta',delta:'مرحبا'})+'\r\n\r\ndata: {"type":"response.completed"}\n\n';
  assert.equal(await readEvents(stream(text)),'مرحبا');
  await assert.rejects(readEvents(stream('data: {"type":"response.output_text.delta","delta":"partial"}\n')));
  await assert.rejects(readEvents(stream('data: {"type":"response.failed","response":{"error":{"code":"subscription_sharing_usage_limit_exceeded"}}}\n')));
});
