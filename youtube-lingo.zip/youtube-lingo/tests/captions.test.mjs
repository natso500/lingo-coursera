import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import '../extension/core.js';

const js = await readFile(new URL('../extension/captions.js', import.meta.url), 'utf8');
const origin = 'https://www.youtube.com';
const id = 'abcdefghijk';
const next = 'ABCDEFGHIJK';
const url = origin+'/api/timedtext?v='+id+'&lang=en&signature=fixture';
const sample = {events:[{tStartMs:0, dDurationMs:1500, segs:[{utf8:'Hello'}, {utf8:' world'}]},
  {tStartMs:2600, dDurationMs:2000, segs:[{utf8:'Next sentence.'}]}]};

function fixture({resources = [], fetch = async () => assert.fail('Unexpected request'), readTranscript} = {}) {
  const location = new URL(origin+'/watch?v='+id);
  let queued = [];
  class Observer {
    constructor(callback) { this.callback = callback; }
    observe(options) { assert.equal(options.type, 'resource'); }
    takeRecords() { const copy = queued; queued = []; return copy; }
  }
  const ctx = vm.createContext({URL, AbortSignal, TextDecoder, location, fetch,
    LingoCore, performance:{getEntriesByType:() => resources.map(name => ({name}))},
    PerformanceObserver:Observer, YouTubeTranscript: readTranscript && {read:readTranscript}});
  vm.runInContext(js, ctx);
  let showingAd = false, watchId = id;
  const player = {matches:() => showingAd, closest:() => ({getAttribute:() => watchId})};
  const video = {isConnected:true, duration:60, closest:() => player, textTracks:[], querySelectorAll:() => []};
  return {captions:ctx.YouTubeCaptions, video, location,
    ad(value) { showingAd = value; }, setWatchId(value) { watchId = value; }, observe(name) {queued.push({name});}};
}

test('reads exact English timedtext URL for current video, ignores lookalikes, translations, other videos and live chunks', async () => {
  const f = fixture({resources:[url, url.replace('www.youtube.com', 'www.youtube.com.fake.test'),
    url.replace(id,next), url.replace('lang=en', 'lang=es'), url+'&tlang=ar', url+'&sq=1',
    url.replace('/api/timedtext?', '/api/timedtext-other?')], fetch:async (input,opts) => {
      assert.equal(input,url);
      assert.equal(opts.credentials,'same-origin');
      assert.equal(opts.redirect,'error');
      return Response.json(sample);
    }});
  const cues = await f.captions.read(f.video);
  assert.deepEqual(Array.from(cues,c=>[c.id,c.start,c.end,c.text]),
    [[0,0,1.5,'Hello world'],[1,2.6,4.6,'Next sentence.']]);
});

test('handles ASR JSON3 overlapping display windows, word segments and empty append events', async () => {
  const f = fixture({resources:[url+'&kind=asr'],fetch:async () => Response.json({events:[
    {tStartMs:500,dDurationMs:3400,segs:[{utf8:'word'}, {tOffsetMs:200,utf8:' one'}]},
    {tStartMs:1800,dDurationMs:1000,aAppend:1,segs:[{utf8:'\n'}]},
    {tStartMs:2000,dDurationMs:3000,segs:[{utf8:'word two'}]}
  ]})});
  assert.deepEqual(Array.from(await f.captions.read(f.video),c=>[c.start,c.end,c.text]),
    [[0.5,2,'word one'],[2,5,'word two']]);
});

test('rolling VTT removes carried lines and tiny display-only repeats, keeps genuine repetition after a gap', async () => {
  const f = fixture({resources:[url+'&kind=asr'],fetch:async () => new Response(
    'WEBVTT\n\n00:00.000 --> 00:01.000\none\n\n00:01.000 --> 00:01.010\none\n\n'+
    '00:01.010 --> 00:02.000\none\ntwo\n\n00:02.000 --> 00:02.010\ntwo\n\n'+
    '00:02.010 --> 00:03.000\ntwo\nthree\n\n00:04.000 --> 00:05.000\nthree')});
  assert.deepEqual(Array.from(await f.captions.read(f.video),c=>c.text), ['one','two','three','three']);
});

test('scope changes on watch navigation and ads, including while parsing a response', async () => {
  const f = fixture({resources:[url], fetch:async () => {
    f.location.search='?v='+next;
    f.setWatchId(next);
    return Response.json(sample);
  }});
  await assert.rejects(f.captions.read(f.video), /تغيّر الفيديو/);
  assert.equal(f.captions.assetId(f.video),next);
  f.ad(true);
  assert.equal(f.captions.assetId(f.video),'');
  f.ad(false);
  f.setWatchId(id);
  assert.equal(f.captions.assetId(f.video),'');
});

test('picks up a newly observed track and prefers an authored track to auto-captions', async () => {
  const f = fixture({resources:[url+'&kind=asr'], fetch:async input => {
    assert.equal(input,url);
    return Response.json(sample);
  }});
  f.observe(url);
  assert.equal((await f.captions.read(f.video)).length,2);
});

test('uses a native English caption track; empty or forbidden timedtext falls back to the visible transcript', async () => {
  const fallback = [{id:0,start:0,end:1,text:'From transcript'}];
  const f = fixture({resources:[url], fetch:async () => new Response(null,{status:403}),
    readTranscript:async video => {assert.equal(video,f.video);return fallback;}});
  f.video.textTracks = [{kind:'subtitles',language:'en-GB',cues:[{startTime:5,endTime:6,text:'Native'}]}];
  assert.equal((await f.captions.read(f.video))[0].text,'Native');
  f.video.textTracks=[];
  assert.equal(await f.captions.read(f.video),fallback);
});


test('retains genuine repeated words in ASR events with overlapping nominal durations', async () => {
  const f = fixture({resources: [url+'&kind=asr'], fetch: async () => Response.json({events:[
    {tStartMs:0,dDurationMs:2000,segs:[{utf8:'Yes.'}]},
    {tStartMs:1000,dDurationMs:2000,segs:[{utf8:'Yes.'}]}
  ]})});
  assert.deepEqual(Array.from(await f.captions.read(f.video), c => [c.start, c.end, c.text]),
    [[0,1,'Yes.'],[1,3,'Yes.']]);
});
