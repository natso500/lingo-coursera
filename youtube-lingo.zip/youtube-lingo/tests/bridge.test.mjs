import {test} from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {readFile} from 'node:fs/promises';
const read = name => readFile(new URL('../extension/'+name+'.js',import.meta.url),'utf8');
const id='abcdefghijk', url='https://www.youtube.com/api/timedtext?v='+id+'&lang=en';

test('reads only current English track metadata from watch player', async () => {
  const d=new JSDOM('<div id="movie_player"><video></video></div>',{url:'https://www.youtube.com/watch?v='+id,runScripts:'outside-only'});
  try {
    const w=d.window, player=w.document.querySelector('#movie_player');
    player.getPlayerResponse=()=>({videoDetails:{videoId:id}, captions:{playerCaptionsTracklistRenderer:{captionTracks:[{languageCode:'en',baseUrl:url},{languageCode:'fr',baseUrl:url+'&bad=1'}]}}});
    const requests=[];
    w.fetch=async input=>{requests.push(input);return Response.json({events:[{tStartMs:0,dDurationMs:1000,segs:[{utf8:'Hello'}]}]});};
    w.AbortSignal=AbortSignal; w.TextDecoder=TextDecoder;
    for(const name of ['player-bridge','core','captions']) w.eval(await read(name));
    const cues=await w.YouTubeCaptions.read(player.querySelector('video'));
    assert.equal(cues[0].text,'Hello'); assert.deepEqual(requests,[url]);
    player.getPlayerResponse=()=>({videoDetails:{videoId:'ABCDEFGHIJK'},captions:{playerCaptionsTracklistRenderer:{captionTracks:[{languageCode:'en',baseUrl:url}]}}});
    await assert.rejects(w.YouTubeCaptions.read(player.querySelector('video')));
    assert.equal(requests.length,1);
  } finally {d.window.close();}
});
