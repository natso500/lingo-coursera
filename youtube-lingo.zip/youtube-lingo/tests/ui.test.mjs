import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';

async function fixture({load=true, hasTrack=true, cache=new Map()} = {}) {
  const dom = new JSDOM('<ytd-watch-flexy video-id="abcdefghijk"><div id="movie_player"><video class="html5-main-video"></video></div></ytd-watch-flexy>', {
    url: 'https://www.youtube.com/watch?v=abcdefghijk', runScripts: 'outside-only'
  });
  const w = dom.window;
  let frame, root, finishBatch;
  const sent = [];
  const attach = w.Element.prototype.attachShadow;
  w.Element.prototype.attachShadow = function (options) { return root = attach.call(this, options); };
  w.requestAnimationFrame = fn => { frame = fn; };
  Object.defineProperty(w.crypto, 'subtle', {value: crypto.subtle});
  w.TextEncoder = TextEncoder;
  const video = w.document.querySelector('video');
  video.getBoundingClientRect = () => ({width: 700, height: 390, left: 0, top: 0, bottom: 390});
  const track = {kind:'captions', language:'en', cues: Array.from({length:8}, (_, i) =>
    ({startTime:i, endTime:i+1, text:'Line '+i}))};
  Object.defineProperty(video, 'textTracks', {value:hasTrack ? [track] : []});
  w.chrome = {runtime: {sendMessage: async ({type, payload}) => {
    let data;
    switch (type) {
      case 'cacheGet': data = {data:cache.get(payload.key)}; break;
      case 'cacheSet': cache.set(payload.key,payload.data); break;
      case 'models': data = {models:[{id:'model',name:'Test model'}]}; break;
      case 'translate':
        sent.push(payload);
        await new Promise(resolve => { finishBatch = resolve; });
        data = {rows:payload.cues.map(({id}) => ({id, text:'الترجمة ' + id}))};
        break;
      default: throw new Error('Unexpected request ' + type);
    }
    return {ok:true,data};
  }}};
  for (const name of ['captions','core','panel','content']) {
    w.eval(await readFile(new URL('../extension/'+name+'.js', import.meta.url), 'utf8'));
  }
  const el = id => root.getElementById(id);
  if (load) await el('load').onclick();
  await el('models').onclick();
  el('model').value='model';
  return {dom, el, sent, cache, video, frame: time=>frame(time), finish:()=>finishBatch()};
}

test('stop completes one batch, resume requests the remaining cues and preserves timing', async () => {
  const f = await fixture();
  try {
    const first = f.el('start').onclick();
    assert.deepEqual(Array.from(f.sent[0].cues, c=>c.id), [0,1,2,3,4,5]);
    f.el('stop').onclick();
    f.finish();
    await first;
    assert.match(f.el('status').textContent, /تم الإيقاف/);
    assert.equal(f.el('progress').value, 6);
    const second = f.el('start').onclick();
    assert.deepEqual(Array.from(f.sent[1].cues,c=>c.id),[6,7]);
    f.finish();
    await second;
    f.video.currentTime = 7.5;
    f.frame(300);
    assert.equal(f.el('arabic').textContent,'الترجمة 7');
    assert.equal(f.el('original').textContent,'Line 7');
    f.video.currentTime = 8;
    f.frame(500);
    assert.equal(f.el('arabic').textContent,'');
  } finally { f.dom.window.close(); }
});

test('changing the watch query while ChatGPT is working discards the previous video result', async () => {
  const f = await fixture();
  try {
    const work = f.el('start').onclick();
    f.dom.window.history.pushState({},'', '/watch?v=ponmlkjihgf');
    f.video.closest('ytd-watch-flexy').setAttribute('video-id', 'ponmlkjihgf');
    f.frame(250);
    f.finish();
    await work;
    assert.equal(f.el('progress').value,0);
    assert.equal(f.el('arabic').textContent,'');
    assert.equal(f.cache.size,0);
  } finally { f.dom.window.close(); }
});

test('an ad hides captions, blocks source reading, and preserves the watch video batch and timing', async () => {
  const f = await fixture();
  try {
    f.video.currentTime = 2;
    f.frame(100);
    assert.equal(f.el('original').textContent, 'Line 2');
    const player = f.video.closest('#movie_player');
    assert.equal(player.hasAttribute('data-youtube-lingo-overlay'), true);

    const work = f.el('start').onclick();
    f.el('stop').onclick();
    player.classList.add('ad-showing');
    f.video.currentTime = 0;
    f.frame(250);
    assert.equal(f.el('captions').hidden, true);
    assert.equal(player.hasAttribute('data-youtube-lingo-overlay'), false);
    f.finish();
    await work;
    assert.equal(f.el('progress').value, 6);

    await f.el('load').onclick();
    assert.match(f.el('status').textContent, /الإعلان/);
    player.classList.remove('ad-showing');
    f.video.currentTime = 3;
    f.frame(500);
    assert.equal(f.el('captions').hidden, false);
    assert.equal(f.el('arabic').textContent, 'الترجمة 3');
    assert.equal(f.sent.length, 1);
  } finally { f.dom.window.close(); }
});

test('an old watch player during an SPA transition cannot supply the new video captions', async () => {
  const f = await fixture();
  try {
    f.dom.window.history.pushState({}, '', '/watch?v=ponmlkjihgf');
    f.frame(200);
    await f.el('load').onclick();
    assert.equal(f.el('captions').hidden, true);
    assert.equal(f.el('progress').value, 0);
    assert.equal(f.el('original').textContent, '');
    assert.equal(f.sent.length, 0);

    f.dom.window.history.pushState({}, '', '/');
    f.frame(400);
    assert.equal(f.dom.window.document.querySelector('#youtube-lingo').hidden, true);
  } finally { f.dom.window.close(); }
});


test('original controls, no request cap, one click translates all batches', async () => {
  const f = await fixture();
  try {
    for (const id of ['budget','batchSize','estimate','sync','exportSrt']) assert.equal(f.el(id),null);
    assert.equal(f.el('start').textContent,'ترجمة الفيديو');
    const work=f.el('start').onclick();
    f.finish();
    for (let i=0;i<100 && f.sent.length<2;i++) await new Promise(r=>setTimeout(r,5));
    assert.equal(f.sent.length,2);
    assert.equal(f.el('progress').value,6);
    f.finish(); await work;
    assert.equal(f.el('progress').value,8);
    assert.match(f.el('status').textContent,/اكتملت الترجمة/);
  } finally { f.dom.window.close(); }
});

test('imports standalone SRT with no source captions and restores it in a fresh session', async () => {
  const f = await fixture({load:false,hasTrack:false});
  try {
    f.el('import').onclick();
    Object.defineProperty(f.el('file'), 'files', {value:[{name:'ar.srt',size:90,text:async ()=>'1\n00:00:02,000 --> 00:00:04,000\nمرحبا بالعالم'}]});
    await f.el('file').onchange();
    assert.match(f.el('status').textContent, /تم استيراد/);
    f.video.currentTime = 2.5; f.frame(200);
    assert.equal(f.el('arabic').textContent,'مرحبا بالعالم');
    f.video.currentTime=4; f.frame(400);
    assert.equal(f.el('arabic').textContent,'');
    assert.equal(f.sent.length,0);
    const g = await fixture({load:false,hasTrack:false,cache:f.cache});
    try {
      for (let i=0;i<30 && !g.el('progress').value;i++) await new Promise(r=>setTimeout(r,5));
      g.video.currentTime=3; g.frame(200);
      assert.equal(g.el('arabic').textContent,'مرحبا بالعالم');
      assert.equal(g.sent.length,0);
      await g.el('clear').onclick(); g.frame(400);
      assert.equal(g.el('captions').hidden,true);
    } finally { g.dom.window.close(); }
  } finally { f.dom.window.close(); }
});

test('restores a partial automatic translation and resumes remaining IDs', async () => {
  const f=await fixture();
  try {
    const work=f.el('start').onclick(); f.el('stop').onclick(); f.finish(); await work;
    const g=await fixture({load:false,cache:f.cache});
    try {
      for (let i=0;i<30 && g.el('progress').value!==6;i++) await new Promise(r=>setTimeout(r,5));
      assert.equal(g.el('progress').value,6);
      const next=g.el('start').onclick();
      assert.deepEqual(Array.from(g.sent[0].cues,c=>c.id),[6,7]);
      g.finish(); await next;
      assert.equal(g.el('progress').value,8);
    } finally {g.dom.window.close();}
  } finally {f.dom.window.close();}
});
