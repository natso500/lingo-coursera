/* Read English captions exposed by YouTube's watch player or its transcript panel. */
(() => {
  const observed = new Map();
  const endpoint = location.origin + '/api/timedtext?';
  const english = /^en(?:[-_]|$)/i;

  function assetId(video) {
    if (!video?.isConnected || location.pathname !== '/watch') return '';
    const id = new URL(location.href).searchParams.get('v') || '';
    if (!/^[A-Za-z0-9_-]{11}$/.test(id)) return '';
    const player = video.closest('#movie_player');
    if (!player || player.matches('.ad-showing, .ad-interrupting')) return '';
    const watchId = player.closest('ytd-watch-flexy, ytd-watch-grid')?.getAttribute('video-id');
    return !watchId || watchId === id ? id : '';
  }

  function source(raw) {
    if (typeof raw !== 'string' || !raw.startsWith(endpoint)) return null;
    let url;
    try { url = new URL(raw); } catch { return null; }
    const params = url.searchParams;
    const id = params.get('v');
    if (!/^[A-Za-z0-9_-]{11}$/.test(id || '') || !english.test(params.get('lang') || '') ||
        params.has('tlang') || params.has('sq')) return null;
    return {id, url:raw, automatic:params.get('kind') === 'asr'};
  }

  function record(entries) {
    for (const {name} of entries) {
      const file = source(name);
      if (!file) continue;
      const tracks = observed.get(file.id) || new Map();
      tracks.set(file.automatic, file);
      observed.delete(file.id);
      observed.set(file.id, tracks);
      if (observed.size > 24) observed.delete(observed.keys().next().value);
    }
  }

  let observer;
  if (typeof PerformanceObserver === 'function') {
    observer = new PerformanceObserver(list => record(list.getEntries()));
    try { observer.observe({type:'resource', buffered:true}); } catch { observer = undefined; }
  }
  record(performance.getEntriesByType?.('resource') || []);

  function normalize(text) {
    return text.trim().split(/\r?\n/).map(line => line.replace(/[ \t]+/g, ' ').trim()).filter(Boolean).join('\n');
  }

  function timeline(rows, automatic, duration) {
    const timed = rows.filter(row => Number.isFinite(row.start) && row.start >= 0 && row.text?.trim())
      .sort((left, right) => left.start - right.start);
    const cues = [];
    let previousDisplay = '';
    for (let i = 0; i < timed.length; i++) {
      const {start, text} = timed[i];
      const nextStart = timed[i + 1]?.start;
      let end = timed[i].end;
      if (!Number.isFinite(end) || end <= start) end = nextStart ?? (start + 4);
      if (Number.isFinite(duration) && duration > 0) end = Math.min(end, duration);
      if (end <= start) continue;

      const display = normalize(text);
      const previous = cues.at(-1);
      let line = display;
      if (automatic && previous && previous.end >= start - 0.02) {
        // YouTube's rolling VTT often repeats a line for 10 ms, then prefixes it
        // to the next line. Remove the carried line only at that shared boundary.
        if ((display === previousDisplay || display === previous.text) && (start === previous.start || end - start <= 0.02)) {
          previous.end = Math.max(previous.end, end);
          continue;
        }
        const carried = previousDisplay.split('\n').at(-1);
        if (display.startsWith(carried + '\n')) line = display.slice(carried.length + 1);
        if (start > previous.start && previous.end > start) previous.end = start;
      }
      previousDisplay = display;
      cues.push({id:cues.length, start, end, text:line});
    }
    return cues;
  }

  function nativeCues(video) {
    for (const track of Array.from(video.textTracks || [])) {
      if (!['subtitles', 'captions'].includes(track.kind) ||
          !(english.test(track.language || '') || (!track.language && /^English\b/i.test(track.label))) ||
          !track.cues?.length) continue;
      const rows = Array.from(track.cues, cue => ({
        start:cue.startTime, end:cue.endTime, text:cue.getCueAsHTML?.().textContent || cue.text || ''
      }));
      const cues = timeline(rows, /auto.generated/i.test(track.label), video.duration);
      if (cues.length) return cues;
    }
    return [];
  }

  function jsonRows(text) {
    const events = JSON.parse(text).events;
    if (!Array.isArray(events)) return [];
    return events.filter(event => Number.isFinite(event?.tStartMs) && Array.isArray(event.segs))
      .map(event => ({
        start:event.tStartMs / 1000,
        end:Number.isFinite(event.dDurationMs) ? (event.tStartMs + event.dDurationMs) / 1000 : NaN,
        text:event.segs.map(segment => typeof segment?.utf8 === 'string' ? segment.utf8 : '').join('')
      }));
  }

  function xmlRows(text) {
    // srv3 uses milliseconds in p elements. Older tracks use seconds in text.
    const doc = new DOMParser().parseFromString(text, 'application/xml');
    if (doc.querySelector('parsererror')) return [];
    return Array.from(doc.querySelectorAll('body p[t], transcript > text[start]'), node => {
      const ms = node.hasAttribute('t');
      const scale = ms ? 1000 : 1;
      const start = Number(node.getAttribute(ms ? 't' : 'start')) / scale;
      const length = Number(node.getAttribute(ms ? 'd' : 'dur')) / scale;
      for (const br of node.querySelectorAll('br')) br.replaceWith(doc.createTextNode('\n'));
      return {start, end:start + length, text:node.textContent};
    });
  }

  async function readFile(file, video) {
    const response = await fetch(file.url, {
      credentials:'same-origin', redirect:'error', signal:AbortSignal.timeout(10000)
    });
    if (!response.ok || !response.body) return [];
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let text = '', bytes = 0;
    for (;;) {
      const {done, value} = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 4_000_000) {
        await reader.cancel();
        throw new Error('ملف الشرح النصي كبير جدًا.');
      }
      text += decoder.decode(value, {stream:true});
    }
    text = (text + decoder.decode()).trim();
    let rows = [];
    if (text.startsWith('{')) rows = jsonRows(text);
    else if (text.startsWith('<')) rows = xmlRows(text);
    else if (text.startsWith('WEBVTT')) rows = LingoCore.parse(text);
    return timeline(rows, file.automatic, video.duration);
  }

  async function read(video) {
    const id = assetId(video);
    if (!id) throw new Error('افتح الفيديو في صفحة المشاهدة وانتظر انتهاء الإعلان.');
    function verify() {
      if (assetId(video) !== id) throw new Error('تغيّر الفيديو أثناء قراءة الترجمة. أعد قراءة نص الفيديو الحالي.');
    }
    // Only use URLs already supplied by this watch player, with their original
    // query intact. A segmented live-caption request is not a full transcript.
    record(observer?.takeRecords() || performance.getEntriesByType?.('resource') || []);
    const tracks = new Map(observed.get(id));
    // Ask the page for track metadata already provided to the current player.
    // Only accept exact same-origin English timedtext URLs for this video.
    if (typeof document !== 'undefined' && typeof CustomEvent === 'function') {
      const receive = event => {
        try {
          if (typeof event.detail !== 'string' || event.detail.length > 100000) return;
          const result = JSON.parse(event.detail);
          if (result.id !== id || !Array.isArray(result.urls)) return;
          for (const raw of result.urls.slice(0,16)) {
            const file = source(raw);
            if (file?.id === id && !tracks.has(file.automatic)) tracks.set(file.automatic, file);
          }
        } catch { /* Invalid page data is ignored. */ }
      };
      document.addEventListener('lingo:tracks:response', receive);
      try { document.dispatchEvent(new CustomEvent('lingo:tracks:request', {detail:id})); }
      finally { document.removeEventListener('lingo:tracks:response', receive); }
    }
    for (const node of video.querySelectorAll('track[src]')) {
      const file = source(node.src);
      if (file?.id === id) tracks.set(file.automatic, file);
    }
    const native = nativeCues(video);
    if (native.length) return native;
    for (const automatic of [false, true]) {
      const file = tracks.get(automatic);
      if (!file) continue;
      let cues;
      try { cues = await readFile(file, video); }
      catch { cues = []; }
      verify();
      if (cues.length) return cues;
    }
    if (globalThis.YouTubeTranscript) {
      const cues = await globalThis.YouTubeTranscript.read(video);
      verify();
      if (cues?.length) return cues;
    }
    throw new Error('اختر الإنجليزية من زر CC أو افتح نص الفيديو بالإنجليزية، ثم اضغط قراءة النص الأصلي.');
  }

  globalThis.YouTubeCaptions = {assetId, read};
})();

