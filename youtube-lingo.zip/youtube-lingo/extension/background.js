const base = 'http://127.0.0.1:43129';
const storageReady = chrome.storage.local.setAccessLevel({accessLevel: 'TRUSTED_CONTEXTS'});
let pendingSave = Promise.resolve();

async function cache(type, {key, data}) {
  if (!/^v1-ar-[a-f0-9]{64}$/.test(key)) throw new Error('بصمة الفيديو غير صالحة.');
  const storageKey = 'captions:' + key;
  if (type === 'cacheGet') {
    await pendingSave;
    const saved = await chrome.storage.local.get(storageKey);
    return {data: saved[storageKey]?.data};
  }
  if (new TextEncoder().encode(JSON.stringify(data)).length > 750000) {
    throw new Error('الترجمة كبيرة جدًا للحفظ المحلي. يمكنك تصديرها قبل إغلاق الصفحة.');
  }
  const save = pendingSave.then(async () => {
    await chrome.storage.local.set({[storageKey]: {data, updated: Date.now()}});
    const all = await chrome.storage.local.get(null);
    const older = Object.entries(all).filter(([name]) => name.startsWith('captions:'))
      .sort((a, b) => b[1].updated - a[1].updated).slice(8).map(([name]) => name);
    if (older.length) await chrome.storage.local.remove(older);
  });
  pendingSave = save.catch(() => {});
  await save;
  return {};
}

async function request(message, isOptions) {
  await storageReady;
  const {type, payload = {}} = message;
  if (!isOptions) {
    if (type === 'options') {
      await chrome.runtime.openOptionsPage();
      return {};
    }
    if (type === 'cacheGet' || type === 'cacheSet') return cache(type, payload);
  }
  const routes = isOptions ? ['login', 'logout', 'status'] : ['models', 'translate', 'status'];
  if (!routes.includes(type)) throw new Error('العملية غير مدعومة.');
  const {connectorKey} = await chrome.storage.local.get('connectorKey');
  if (!connectorKey) throw new Error('افتح إعداد الاتصال وأدخل رمز الربط من نافذة مساعد YouTube Lingo.');
  let response;
  try {
    response = await fetch(base + '/' + type, {
      method: 'POST', credentials: 'omit', redirect: 'error',
      headers: {'Content-Type': 'application/json', 'X-Lingo-Key': connectorKey},
      body: JSON.stringify(payload), signal: AbortSignal.timeout(24000)
    });
  } catch (error) {
    if (error.name === 'TimeoutError') throw new Error('انتهت مهلة المساعد المحلي. تحقق من حالة الاتصال قبل إعادة المحاولة.');
    throw new Error('شغّل START.cmd من مجلد YouTube Lingo ثم أعد المحاولة.');
  }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'تعذر الاتصال بالمساعد المحلي.');
  return data;
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  const isOptions = sender.url === chrome.runtime.getURL('options.html');
  const isYouTube = sender.frameId === 0 && sender.origin === 'https://www.youtube.com';
  if (sender.id !== chrome.runtime.id || (!isOptions && !isYouTube)) return false;
  request(message, isOptions).then(
    data => reply({ok: true, data}),
    error => reply({ok: false, error: error.message || 'تعذر تنفيذ الطلب.'})
  );
  return true;
});
