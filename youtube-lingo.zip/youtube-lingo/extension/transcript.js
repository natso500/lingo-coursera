/* Read the same timed segments shown by YouTube's Show transcript control. */
(() => {
  const panelSelector = 'ytd-engagement-panel-section-list-renderer[visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"]';
  const rowSelector = 'transcript-segment-view-model, ytd-transcript-segment-renderer';
  const openSelector = 'ytd-video-description-transcript-section-renderer button, button[aria-label="Show transcript"], button[aria-label="إظهار النص"]';
  const expandSelector = 'ytd-text-inline-expander #expand, #description-inline-expander #expand';
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  function clockTime(label) {
    const parts = (label || '').trim()
      .replace(/[٠-٩]/g, n => n.charCodeAt(0) - 1632)
      .replace(/[۰-۹]/g, n => n.charCodeAt(0) - 1776)
      .replace(/[\u200e\u200f\u061c]/g, '').split(':');
    if (parts.length < 2 || parts.length > 3 || parts.some((p, i) => !(i ? /^[0-5]\d$/ : /^\d+$/).test(p))) return NaN;
    return parts.reduce((total, part) => total * 60 + Number(part), 0);
  }

  function readRows(panel, duration) {
    const groups = [];
    for (const row of panel.querySelectorAll(rowSelector)) {
      const stamp = row.querySelector('.ytwTranscriptSegmentViewModelTimestamp, .segment-timestamp');
      const label = row.querySelector(':scope > span.ytAttributedStringHost, .segment-text');
      const text = label?.textContent.replace(/\s+/g, ' ').trim();
      const start = clockTime(stamp?.textContent);
      if (!text || !Number.isFinite(start) || (Number.isFinite(duration) && duration > 0 && start >= duration)) continue;
      groups.push({start, text});
    }
    groups.sort((a,b) => a.start - b.start);
    const cues = [];
    for (const row of groups) {
      const last = cues.at(-1);
      if (last?.start === row.start) {
        last.text += '\n' + row.text;
      } else {
        if (last) last.end = row.start;
        cues.push({id:cues.length, start:row.start, end:NaN, text:row.text});
      }
    }
    const last = cues.at(-1);
    if (last) last.end = Number.isFinite(duration) && duration > last.start ? duration : last.start + 4;
    return cues;
  }

  function checkLanguage(panel, cues) {
    const selected = panel.querySelector('ytd-transcript-footer-renderer #label, ytd-transcript-footer-renderer #trigger .yt-dropdown-menu, select option:checked');
    const label = selected?.textContent.trim();
    if (label && !/English|الإنجليزية|الانجليزية|الإنكليزية|\beng\b/i.test(label)) {
      throw new Error('اختر English من قائمة اللغات في لوحة نص يوتيوب ثم أعد القراءة.');
    }
    const sample = cues.slice(0, 15).map(cue => cue.text).join(' ');
    const letters = sample.match(/\p{Letter}/gu)?.length || 0;
    if (letters >= 20 && (sample.match(/\p{Script=Latin}/gu)?.length || 0) < letters / 2) {
      throw new Error('يبدو أن النص المعروض بلغة أخرى. اختر المسار الإنجليزي في يوتيوب ثم أعد القراءة.');
    }
  }

  async function read(video) {
    const id = globalThis.YouTubeCaptions.assetId(video);
    const watch = video.closest('ytd-watch-flexy, ytd-watch-grid') || document;
    const sameVideo = () => Boolean(id && globalThis.YouTubeCaptions.assetId(video) === id);
    const panels = () => Array.from(watch.querySelectorAll(panelSelector));
    const transcriptPanel = () => panels().find(p => p.querySelector(rowSelector));
    const originalPanels = new Set(panels());
    let expanded, opened, panel;
    try {
      if (!sameVideo()) return [];
      panel = transcriptPanel();
      if (!panel) {
        if (!watch.querySelector(openSelector)) {
          const button = watch.querySelector(expandSelector);
          if (button && !button.closest('[hidden]')) {
            expanded = button.closest('ytd-text-inline-expander, #description-inline-expander');
            button.click();
          }
        }
        for (let i = 0; i < 20 && sameVideo(); i++) {
          const trigger = watch.querySelector(openSelector);
          if (trigger) {
            opened = true;
            trigger.click();
            break;
          }
          if (!expanded) break;
          await delay(100);
        }
        if (!opened) return [];
        for (let i = 0; i < 64 && sameVideo(); i++) {
          panel = transcriptPanel();
          if (panel) break;
          await delay(125);
        }
      }
      if (!panel || !sameVideo()) return [];
      // Wait for YouTube to finish inserting the panel rows in this render cycle.
      let count = panel.querySelectorAll(rowSelector).length;
      for (let i = 0; i < 8; i++) {
        await delay(125);
        if (!sameVideo() || transcriptPanel() !== panel) return [];
        const next = panel.querySelectorAll(rowSelector).length;
        if (next === count) break;
        count = next;
      }
      const cues = readRows(panel, video.duration);
      checkLanguage(panel, cues);
      return cues;
    } finally {
      if (sameVideo()) {
        if (opened && panel && !originalPanels.has(panel)) {
          panel.querySelector('#dismiss-button button, button[aria-label="Close"], button[aria-label="إغلاق"]')?.click();
        }
        if (expanded?.isConnected) expanded.querySelector('#collapse')?.click();
      }
    }
  }

  globalThis.YouTubeTranscript = {read};
})();
