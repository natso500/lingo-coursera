/* Shared pure subtitle utilities; no network or browser credentials. */
(() => {
  const time = value => {
    const parts = value.replace(',', '.').split(':').map(Number);
    if (parts.length < 2 || parts.length > 3 || parts.some(n => !Number.isFinite(n) || n < 0)) return NaN;
    if (parts.at(-1) >= 60 || (parts.length === 3 && parts[1] >= 60)) return NaN;
    return parts.reduce((a, n) => a * 60 + n, 0);
  };
  const plain = value => value.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').trim();
  function parse(text) {
    const cues = [];
    for (const block of text.replace(/^\uFEFF/, '').replace(/\r/g, '').split(/\n\s*\n/)) {
      if (/^(WEBVTT|NOTE|STYLE|REGION)(\s|$)/.test(block)) continue;
      const lines = block.split('\n');
      const index = lines.findIndex(l => l.includes('-->'));
      if (index < 0) continue;
      const match = lines[index].match(/^\s*([\d:.,]+)\s+-->\s+([\d:.,]+)/);
      if (!match) continue;
      const start = time(match[1]), end = time(match[2]);
      const body = plain(lines.slice(index + 1).join('\n'));
      if (Number.isFinite(start) && Number.isFinite(end) && end > start && body) cues.push({start, end, text: body});
    }
    return cues.sort((a, b) => a.start - b.start).map((cue, id) => ({...cue, id}));
  }
  function stamp(seconds) {
    const ms = Math.round(seconds * 1000);
    return `${String(Math.floor(ms / 3600000)).padStart(2, '0')}:${String(Math.floor(ms / 60000) % 60).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}.${String(ms % 1000).padStart(3, '0')}`;
  }
  function serialize(cues) {
    return 'WEBVTT\n\n' + cues.map(c => `${stamp(c.start)} --> ${stamp(c.end)}\n${c.text}`).join('\n\n') + '\n';
  }
  function serializeSrt(cues) {
    return cues.map((c, i) => `${i+1}\n${stamp(c.start).replace('.', ',')} --> ${stamp(c.end).replace('.', ',')}\n${c.text}`).join('\n\n') + '\n';
  }
  function batches(cues, max = 6) {
    const result = [];
    let batch = [], size = 0;
    for (const cue of cues) {
      if (cue.text.length > 3000) throw new Error('هناك مقطع أطول من الحد المسموح (3000 حرف). استخدم الترجمة اليدوية.');
      if (batch.length >= max || size + cue.text.length > 12000) {
        result.push(batch); batch = []; size = 0;
      }
      batch.push(cue); size += cue.text.length;
    }
    if (batch.length) result.push(batch);
    return result;
  }
  function active(cues, at) {
    // Subtitle tracks can overlap; collect all active cues instead of losing one.
    return cues.filter(c => c.start <= at && c.end > at);
  }
  function validateTranslation(rows, source) {
    if (!Array.isArray(rows) || rows.length !== source.length) throw new Error('عدد المقاطع المترجمة لا يطابق النص الأصلي.');
    const map = new Map();
    for (const row of rows) {
      if (!row || !Number.isInteger(row.id) || map.has(row.id) || typeof row.text !== 'string' || !row.text.trim() || row.text.length > 6000) throw new Error('صيغة الترجمة غير صالحة.');
      map.set(row.id, row.text.trim());
    }
    return source.map(c => {
      if (!map.has(c.id)) throw new Error('هناك مقطع مفقود من الترجمة.');
      return {...c, text: map.get(c.id)};
    });
  }
  globalThis.LingoCore = {parse, serialize, serializeSrt, batches, stamp, active, validateTranslation};
})();
