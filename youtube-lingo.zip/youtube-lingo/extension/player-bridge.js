/* Read caption-track metadata exposed by the current public watch player. No cookies, tokens or private account data. */
(() => {
  document.addEventListener('lingo:tracks:request', event => {
    const id = new URL(location.href).searchParams.get('v');
    if (location.pathname !== '/watch' || !/^[\w-]{11}$/.test(id || '') || event.detail !== id) return;
    const player = document.querySelector('#movie_player');
    if (!player || player.matches('.ad-showing, .ad-interrupting')) return;
    let response;
    try { response = player.getPlayerResponse?.(); } catch { return; }
    if (response?.videoDetails?.videoId !== id) return;
    const tracks = response.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!Array.isArray(tracks)) return;
    const urls = tracks.filter(t => /^en(?:[-_]|$)/i.test(t.languageCode || '') && typeof t.baseUrl === 'string')
      .slice(0, 16).map(t => t.baseUrl);
    document.dispatchEvent(new CustomEvent('lingo:tracks:response', {detail:JSON.stringify({id, urls})}));
  });
})();
